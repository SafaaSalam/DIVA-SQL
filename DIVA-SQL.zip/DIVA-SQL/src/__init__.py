# DIVA-SQL Package Initialization
