# Agents module initialization
