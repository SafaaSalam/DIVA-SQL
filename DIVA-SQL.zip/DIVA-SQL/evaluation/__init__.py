# Evaluation module initialization
